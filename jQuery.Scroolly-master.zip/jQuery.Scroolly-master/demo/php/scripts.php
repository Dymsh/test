<!--        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        <script>
          less = {
            env: "development",
            async: false,
            fileAsync: false,
            poll: 1000,
            functions: {},
            dumpLineNumbers: "comments",
            relativeUrls: false,
            rootpath: ":/a.com/"
          };
        </script>
        <script src="js/vendor/less-1.7.3.min.js"></script>-->
        <script src="js/scroolly.demo.min.js"></script>
        <script src="../src/jquery.scroolly.js"></script>
