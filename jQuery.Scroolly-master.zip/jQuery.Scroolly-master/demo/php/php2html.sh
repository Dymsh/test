#!/bin/sh

php 0.no-scrolls.php > ../0.no-scrolls.html
php 1.parallax.php > ../1.parallax.html
php 2.back-to-top.php > ../2.back-to-top.html
php 3.sticky.php > ../3.sticky.html
php 4.sticky-reverse.php > ../4.sticky-reverse.html
php 5.progressbar.php > ../5.progressbar.html
php 6.accordion.php > ../6.accordion.html
php 7.menu-spy.php > ../7.menu-spy.html
php 8.staging-a.php > ../8.staging-a.html
php 8.staging-b.php > ../8.staging-b.html
php 9.all-scrolls.php > ../9.all-scrolls.html

